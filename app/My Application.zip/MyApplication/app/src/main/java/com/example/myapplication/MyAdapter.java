package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

public class MyAdapter  extends FirebaseRecyclerAdapter<model,MyAdapter.Myviewholder> {


    public MyAdapter(@NonNull FirebaseRecyclerOptions<model> options) {
        super(options);



    }
    class Myviewholder extends RecyclerView.ViewHolder {

        TextView name,location,food,phone;




        public Myviewholder(@NonNull View itemView) {
            super(itemView);




            name = (TextView) itemView.findViewById(R.id.Name);
            location = (ImageView) itemView.findViewById(R.id.location);
            food = (TextView) itemView.findViewById(R.id.desc);

            phone = (TextView) itemView.findViewById(R.id.number);


        }

    }


    @Override
    protected void onBindViewHolder(@NonNull final Myviewholder myviewholder, int i, @NonNull final model Model) {
        myviewholder.name.setText(Model.getName());
        myviewholder.phone.setText(Model.getPhone());
        myviewholder.location.setText(Model.getLocation());
        myviewholder.food.setText(Model.getFood());





    }




    @NonNull
    @Override
    public Myviewholder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {


        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cardview, null, false);

        return new MyAdapter.Myviewholder(view);
    }






}
